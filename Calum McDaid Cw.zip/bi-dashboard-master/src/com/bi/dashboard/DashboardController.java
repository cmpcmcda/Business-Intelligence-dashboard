package com.bi.dashboard;

import com.bi.dashboard.services.DataService;
import com.bi.dashboard.Sales;
import com.bi.dashboard.services.RefreshService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class DashboardController implements Initializable {

    @FXML
    private MenuItem menuRefreshData, menuSetRefresh;
    @FXML
    private CheckMenuItem menuAutoRefresh;
    @FXML
    private Text lastUpdated, totalSales, highestSellingRegion, bestSellingVehicle, usSales,europeSales,asiaSales;
    @FXML
    private TableView<Sales> dataTable;
    @FXML
    private Pane loadingDash, loadingData;
    @FXML
    private VBox dataPane, dashboardPane;
    @FXML
    private HBox barChartHBox, lineChartHBox, footerLoading;
    @FXML
    private PieChart pieChart;
    @FXML
    private BarChart<?, ?> barChart;
    @FXML
    private TableColumn<Sales, ?> columnQuarter, columnRegion, columnVehicle, columnYear, columnQuantity;
    @FXML
    private ChoiceBox yearSelector, qtrSelector;

    private CheckBox[] checkboxes, lineCheckboxes;

  
    private DataService dataService;
    private RefreshService refreshService;

    private static String markup;
    private List<Sales> sales;

    private List<Integer> QTR;
    private List<Integer> Year;
    private List<String> Regions;
    private List<String> QTRItems;
    private List<String> selectYearItems;

  

    @Override
    public final void initialize(URL url, ResourceBundle rb) {

        
        dataService = new DataService();
        dataService.setSourceURL("http://glynserver2.cms.livjm.ac.uk/DashService/SGetSales");
        dataService.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
            @Override
            public void handle(WorkerStateEvent e) {
                markup = e.getSource().getValue().toString(); 
                sales = (new Gson()).fromJson(markup, new TypeToken<LinkedList<Sales>>() {}.getType());

                Year = sales.stream().map(s -> s.getYear()).distinct().collect(Collectors.toList());
                QTR = sales.stream().map(s -> (s.getQTR())).distinct().collect(Collectors.toList());
                Regions = sales.stream().map(s -> (s.getRegion())).distinct().collect(Collectors.toList());

                selectYearItems = Year.stream().map(o -> o.toString()).collect(Collectors.toList());
                selectYearItems.add("All");
                QTRItems = QTR.stream().map(o -> o.toString()).collect(Collectors.toList());
                QTRItems.add("All");

                yearSelector.setItems(FXCollections.observableArrayList(selectYearItems));
                qtrSelector.setItems(FXCollections.observableArrayList(QTRItems));

                yearSelector.getSelectionModel().selectLast();
                qtrSelector.getSelectionModel().selectLast();

                dataTable.setItems(FXCollections.observableArrayList(sales));
                setBarChart(sales);
                updateLastUpdatedTime();
            }
        });
        dataService.setOnFailed(new EventHandler<WorkerStateEvent>() {
            @Override
            public void handle(WorkerStateEvent e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Data loading error");
                alert.setHeaderText("Data loading error");
                alert.setContentText("Application unable to connect to data service. Please check internet connection and try again.");
                alert.showAndWait();
            }
        });
        dataService.start();

   

     
       
        menuRefreshData.disableProperty().bind(dataService.runningProperty());
        menuAutoRefresh.disableProperty().bind(dataService.runningProperty());
        menuSetRefresh.disableProperty().bind(dataService.runningProperty());

        //Set progress indicator bindings
        loadingDash.visibleProperty().bindBidirectional(loadingData.visibleProperty());
        dataPane.visibleProperty().bindBidirectional(dashboardPane.visibleProperty());
        loadingDash.visibleProperty().bind(dataService.runningProperty());
        dataPane.visibleProperty().bind(dataService.runningProperty().not());
        footerLoading.visibleProperty().bind(dataService.runningProperty());

        //Sets table columns
        columnQuarter.setCellValueFactory(new PropertyValueFactory<>("QTR"));
        columnRegion.setCellValueFactory(new PropertyValueFactory<>("Region"));
        columnVehicle.setCellValueFactory(new PropertyValueFactory<>("Vehicle"));
        columnYear.setCellValueFactory(new PropertyValueFactory<>("Year"));
        columnQuantity.setCellValueFactory(new PropertyValueFactory<>("Quantity"));

        yearSelector.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newYear) {
                if (yearSelector.getSelectionModel().getSelectedItem() != null) {
                    setDashboardByYearQTR();
                } else {
                    yearSelector.getSelectionModel().select(oldValue);
                }
            }
        });
        qtrSelector.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newQTR) {
                if (newQTR != null) {
                    setDashboardByYearQTR();
                } else {
                    qtrSelector.getSelectionModel().select(oldValue);
                }
            }
        });
    }

    private int calculateTotalSales(List<Sales> list) {
        return list.stream().collect(Collectors.summingInt(Sales::getQuantity));
    }
    private double calculateRevenue(int totalSales, double averageVehicleValue) {
        return Math.round(totalSales * averageVehicleValue);
    }

    private double calculateProfit(int totalSales, double averageVehicleValue, double costPerSale) {

        return totalSales * averageVehicleValue - totalSales * costPerSale;
    }

    private void setDashboardByYearQTR() {
        if (yearSelector.getSelectionModel().getSelectedItem().toString().equals("All")) {
            qtrSelector.setDisable(true);
            qtrSelector.getSelectionModel().selectLast();
            setCoreDashboardItems(sales);
        } else {
            qtrSelector.setDisable(false);
            List<Sales> salesByYear = sales.stream().filter(s -> s.getYear() == Integer.parseInt(yearSelector.getSelectionModel().getSelectedItem().toString())).collect(Collectors.toList());
            if (qtrSelector.getSelectionModel().getSelectedItem().toString().equals("All")) {
                setCoreDashboardItems(salesByYear);
            } else {
                List<Sales> salesByYearQTR = salesByYear.stream().filter(s -> s.getQTR() == Integer.parseInt(qtrSelector.getSelectionModel().getSelectedItem().toString())).collect(Collectors.toList());
                setCoreDashboardItems(salesByYearQTR);
            }
        }
    }

    private void setCoreDashboardItems(List<Sales> list) {
        int numberOfSales = calculateTotalSales(list);
        setTotalSales(numberOfSales);
        setHighestSellingRegion(list);
        setBestSellingVehicle(list);
        setPieChart(list);
        setUSSales(list);
        setEuropeSales(list);
        setAsiaSales(list);
    }

    private void setTotalSales(int totalSales) {
        this.totalSales.setText(String.valueOf(totalSales));
    }
    private void setUSSales(List<Sales> list) {
        int usSalesV = list.stream().filter(s -> s.getRegion().equals("America")).collect(Collectors.summingInt(Sales::getQuantity));
        this.usSales.setText(String.valueOf(usSalesV));
    }
    private void setEuropeSales(List<Sales> list) {
        int europeSalesV = list.stream().filter(s -> s.getRegion().equals("Europe")).collect(Collectors.summingInt(Sales::getQuantity));
        this.europeSales.setText(String.valueOf(europeSalesV));
    }
    private void setAsiaSales(List<Sales> list) {
        int asiaSalesV = list.stream().filter(s -> s.getRegion().equals("Asia")).collect(Collectors.summingInt(Sales::getQuantity));
        this.asiaSales.setText(String.valueOf(asiaSalesV));
    }
  

    private void setHighestSellingRegion(List<Sales> list) {
        Map<String, Integer> map = list.stream().collect(Collectors.groupingBy(Sales::getRegion, Collectors.summingInt(Sales::getQuantity)));
        highestSellingRegion.setText(Collections.max(map.entrySet(), Map.Entry.comparingByValue()).getKey());
    }

    private void setBestSellingVehicle(List<Sales> list) {
        Map<String, Integer> map = list.stream().collect(Collectors.groupingBy(Sales::getVehicle, Collectors.summingInt(Sales::getQuantity)));
        bestSellingVehicle.setText(Collections.max(map.entrySet(), Map.Entry.comparingByValue()).getKey());
    }
    
    

    private void setPieChart(List<Sales> list) {
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        Map<String, Integer> data = list.stream().collect(Collectors.groupingBy(Sales::getRegion, Collectors.summingInt(Sales::getQuantity)));
        data.entrySet().forEach((entry) -> {
            pieChartData.add(new PieChart.Data(entry.getKey(), entry.getValue()));
        });
        this.pieChart.setData(pieChartData);
    }

    private void setBarChart(List<Sales> list) {
        barChartHBox.getChildren().clear();
        checkboxes = new CheckBox[Regions.size()];

        for (byte index = 0; index < Regions.size(); index++) {
            checkboxes[index] = new CheckBox(String.valueOf(Regions.get(index)));
            checkboxes[index].setSelected(true);
            checkboxes[index].addEventFilter(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                }
            });
            checkboxes[index].addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                }
            });
            checkboxes[index].setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent e) {
                    constructBarChartSeries(list);
                }
            });

            barChartHBox.getChildren().add(checkboxes[index]);
        }
        constructBarChartSeries(list);
    }

    private void constructBarChartSeries(List<Sales> list) {
        Map<String, Map<String, Integer>> map = list.stream().collect(Collectors.groupingBy(Sales::getRegion, Collectors.groupingBy(Sales::getVehicle, Collectors.summingInt(Sales::getQuantity))));
        barChart.getData().clear();
        for (CheckBox checkbox : checkboxes) {
            if (checkbox.isSelected()) {
                XYChart.Series series = new XYChart.Series();
                series.setName(checkbox.getText());

                map.entrySet().forEach((entry) -> {
                    if (entry.getKey().equals(checkbox.getText())) {
                        entry.getValue().entrySet().forEach((innerEntry) -> {
                            series.getData().add(new XYChart.Data<>(innerEntry.getKey(), innerEntry.getValue()));
                        });
                    }
                });
                barChart.getData().add(series);
            }
        }
    }

 

    private void updateLastUpdatedTime() {
        lastUpdated.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
    }

    @FXML
    protected final void refreshData() {
        dataService.restart();
    }

    @FXML
    protected final void cancelDataService() {
        dataService.cancel();
    }

    @FXML
    protected final void displaySetRefreshTimeMenu() {
        double currentValue = refreshService.getWaitTime() / 60000.0;
        TextInputDialog dialog = new TextInputDialog(String.valueOf(currentValue));
        dialog.setTitle("Refresh Wait Time");
        dialog.setHeaderText("Configure Refresh Wait Time");
        dialog.setContentText("Please enter the new refresh wait time: (mins)");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(value -> {
            try {
                refreshService.setWaitTime((int) Math.round(Double.parseDouble(value) * 60000));
                refreshService.restart();
            } catch (NumberFormatException e) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Input Error");
                alert.setHeaderText("Input Error");
                alert.setContentText("Please insert the value in minuites:");
                alert.showAndWait();
            }
        });
    }

    @FXML
    protected final void close() {
        Platform.exit();
    }
}
