package com.bi.dashboard;

import java.util.Map;
import java.util.stream.Collector;

public class Sales {
    // NOTE : .NET Property Syntax !
    final private Integer Year, QTR, Quantity; 
    final private String Region, Vehicle;

    /*
    public Sales() { 

    }
    */

    public Sales(Integer year, Integer QTR, String region, String vehicle, Integer quantity) { 
        this.Year = year;
        this.QTR = QTR;
        this.Region = region;
        this.Vehicle = vehicle;
        this.Quantity = quantity;
    }

    @Override
    public String toString() {
        return String.format("%s%s%s%s%s", ("Year:" + Year + " "), ("QTR:" + QTR + " "), (Region != null ? ("Region:" + Region + " ") : ""), (Vehicle != null ? ("Vehicle:" + Vehicle + " ") : ""), ("Quantity:" + Quantity));
    }
 
    // ToDo : setMethods ?

    public Integer getYear() {
        return Year;
    }

    public Integer getQTR() {
        return QTR;
    }

    public String getRegion() {
        return Region;
    }

    public String getVehicle() {
        return Vehicle;
    }

    public Integer getQuantity() {
        return Quantity;
    }

    Collector<Sales, ?, Map<Object, Integer>> getYearString() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
